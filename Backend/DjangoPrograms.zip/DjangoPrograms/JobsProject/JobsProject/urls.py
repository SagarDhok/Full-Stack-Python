"""
URL configuration for JobsProject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from Jobsapp.views import home_page_view,hydjobs_info,punejobs_info,banglorejobs_info


urlpatterns = [
    path('admin/', admin.site.urls),
    path("",home_page_view),
    path("hyd/",hydjobs_info),
    path("pune/",punejobs_info),
    path("bang/",banglorejobs_info),
    path('api/',include('Jobsapp.api.urls'))
]
